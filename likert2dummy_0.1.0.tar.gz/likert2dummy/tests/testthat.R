library(testthat)
library(likert2dummy)

test_check("likert2dummy")
